package com.curso.android.app.practica.proyectofinal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import com.curso.android.app.practica.proyectofinal.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.button.setOnClickListener{compareText()}

    }
    private fun compareText(String texto1) {
        val stringInEditTextOne = binding.text.toString()
        val stringInEditTextTwo = binding.text1.toString()
        if (stringInEditTextOne.isBlank() or stringInEditTextTwo.isBlank())
        {
            binding.textView2.text = ""
               return
        }
        if (stringInEditTextOne == stringInEditTextTwo)
        {
            "Los textos son iguales".also { binding.textView2.text = it }
            return
        }
        binding.textView2.text = buildString {
        append("Los textos No son iguales")
    }
    }
}